import { Student } from '@/types';

export const parseCSV = (csvContent: string): Student[] => {
  const lines = csvContent.trim().split('\n');
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  
  const nameIndex = headers.findIndex(h => h.includes('name'));
  const emailIndex = headers.findIndex(h => h.includes('email'));
  const classIndex = headers.findIndex(h => h.includes('class'));
  
  if (nameIndex === -1) {
    throw new Error('CSV must contain a "name" column');
  }

  const students: Student[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim());
    
    if (values[nameIndex]) {
      students.push({
        id: generateId(),
        name: values[nameIndex],
        email: emailIndex >= 0 ? values[emailIndex] : undefined,
        className: classIndex >= 0 ? values[classIndex] : 'Default Class',
        createdAt: new Date(),
      });
    }
  }
  
  return students;
};

export const generateCSVTemplate = (): string => {
  return 'name,email,class\nJohn Doe,john@example.com,Math 101\nJane Smith,jane@example.com,Math 101\n';
};

const generateId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};