import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Modal,
  StyleSheet,
  Alert,
} from 'react-native';
import { X, Upload, UserPlus } from 'lucide-react-native';
import { useAppContext } from '@/contexts/AppContext';
import { parseCSV, generateCSVTemplate } from '@/utils/csvUtils';

interface AddStudentModalProps {
  visible: boolean;
  onClose: () => void;
}

export const AddStudentModal: React.FC<AddStudentModalProps> = ({
  visible,
  onClose,
}) => {
  const { addStudent, addStudents } = useAppContext();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [className, setClassName] = useState('');
  const [csvInput, setCsvInput] = useState('');
  const [mode, setMode] = useState<'single' | 'csv'>('single');

  const handleAddSingle = () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Please enter a student name');
      return;
    }

    addStudent({
      name: name.trim(),
      email: email.trim() || undefined,
      className: className.trim() || 'Default Class',
    });

    resetForm();
    onClose();
  };

  const handleAddCSV = () => {
    if (!csvInput.trim()) {
      Alert.alert('Error', 'Please paste CSV data');
      return;
    }

    try {
      const students = parseCSV(csvInput);
      if (students.length === 0) {
        Alert.alert('Error', 'No valid student data found in CSV');
        return;
      }

      addStudents(students);
      Alert.alert('Success', `Added ${students.length} students`);
      resetForm();
      onClose();
    } catch (error) {
      Alert.alert('Error', `Failed to parse CSV: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const resetForm = () => {
    setName('');
    setEmail('');
    setClassName('');
    setCsvInput('');
  };

  const showCSVTemplate = () => {
    const template = generateCSVTemplate();
    Alert.alert(
      'CSV Template',
      `Copy this template and fill with your data:\n\n${template}`,
      [{ text: 'OK' }]
    );
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Add Students</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <X size={24} color="#6B7280" />
          </TouchableOpacity>
        </View>

        <View style={styles.modeSelector}>
          <TouchableOpacity
            style={[styles.modeButton, mode === 'single' && styles.activeModeButton]}
            onPress={() => setMode('single')}
          >
            <UserPlus size={20} color={mode === 'single' ? '#FFFFFF' : '#6B7280'} />
            <Text style={[styles.modeText, mode === 'single' && styles.activeModeText]}>
              Single Student
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.modeButton, mode === 'csv' && styles.activeModeButton]}
            onPress={() => setMode('csv')}
          >
            <Upload size={20} color={mode === 'csv' ? '#FFFFFF' : '#6B7280'} />
            <Text style={[styles.modeText, mode === 'csv' && styles.activeModeText]}>
              Import CSV
            </Text>
          </TouchableOpacity>
        </View>

        {mode === 'single' ? (
          <View style={styles.form}>
            <View style={styles.inputGroup}>
              <Text style={styles.label}>Student Name *</Text>
              <TextInput
                style={styles.input}
                value={name}
                onChangeText={setName}
                placeholder="Enter student's full name"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email (Optional)</Text>
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="student@school.edu"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Class Name</Text>
              <TextInput
                style={styles.input}
                value={className}
                onChangeText={setClassName}
                placeholder="Math 101, Science 7A, etc."
              />
            </View>

            <TouchableOpacity style={styles.addButton} onPress={handleAddSingle}>
              <Text style={styles.addButtonText}>Add Student</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.form}>
            <View style={styles.csvHeader}>
              <Text style={styles.label}>CSV Data</Text>
              <TouchableOpacity onPress={showCSVTemplate} style={styles.templateButton}>
                <Text style={styles.templateButtonText}>View Template</Text>
              </TouchableOpacity>
            </View>
            
            <TextInput
              style={styles.csvInput}
              value={csvInput}
              onChangeText={setCsvInput}
              placeholder="Paste your CSV data here..."
              multiline
              textAlignVertical="top"
            />

            <TouchableOpacity style={styles.addButton} onPress={handleAddCSV}>
              <Text style={styles.addButtonText}>Import Students</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: '#111827',
  },
  closeButton: {
    padding: 4,
  },
  modeSelector: {
    flexDirection: 'row',
    margin: 20,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    padding: 4,
  },
  modeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
  },
  activeModeButton: {
    backgroundColor: '#2563EB',
  },
  modeText: {
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  activeModeText: {
    color: '#FFFFFF',
  },
  form: {
    flex: 1,
    paddingHorizontal: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: '#374151',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: '#FFFFFF',
  },
  csvHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  templateButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#E5E7EB',
    borderRadius: 6,
  },
  templateButtonText: {
    fontSize: 12,
    color: '#374151',
    fontWeight: '500',
  },
  csvInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 14,
    backgroundColor: '#FFFFFF',
    minHeight: 200,
    fontFamily: 'monospace',
  },
  addButton: {
    backgroundColor: '#2563EB',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 20,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});